@echo off
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 -X utf8 launch.pyw
  exit /b
)
where python >nul 2>nul
if not errorlevel 1 (
  python -X utf8 launch.pyw
  exit /b
)
echo Please install Python 3.10 or newer from https://www.python.org/downloads/
pause
