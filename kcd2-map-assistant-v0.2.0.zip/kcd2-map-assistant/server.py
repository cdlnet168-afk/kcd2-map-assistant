"""Loopback-only local map notebook. Python standard library; durable JSON storage."""
import argparse,base64,copy,hashlib,json,os,threading,webbrowser,datetime,uuid
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
ROOT=Path(__file__).resolve().parent
DIST=ROOT/"dist"
LOCK=threading.RLock()
STORE=None
MAX=40*1024*1024
KINDS={"main","side","task","dlc","note","danger","resource","herb","item","facility","treasure","goal"}
def validate(value):
    if not isinstance(value,dict) or value.get("schema")!=1:raise ValueError("不是本软件的有效备份")
    if not isinstance(value.get("records"),list) or len(value["records"])>10000:raise ValueError("标记数据无效")
    if value.get("region") not in ("trosky","kuttenberg"):raise ValueError("地图区域无效")
    ids=set()
    for record in value["records"]:
        if not isinstance(record,dict) or not isinstance(record.get("id"),str) or record["id"] in ids:raise ValueError("重复或无效标记")
        ids.add(record["id"])
        if record.get("kind") not in KINDS or record.get("region") not in ("trosky","kuttenberg"):raise ValueError("标记类型或区域无效")
        for axis in ("x","y"):
            n=record.get(axis)
            if n is not None and (isinstance(n,bool) or not isinstance(n,(int,float)) or not 0<=n<=1):raise ValueError("标记坐标必须在地图内")
        if (record.get("x") is None)!=(record.get("y") is None):raise ValueError("坐标不完整")
        if record.get("status") not in ("todo","active","done"):raise ValueError("任务状态无效")
        for key in ("name","en","note","location","risk","reward","prerequisite","giver","precision"):
            if key in record and (not isinstance(record[key],str) or len(record[key])>30000):raise ValueError("文字字段无效")
        source=record.get("source","")
        if source and (not isinstance(source,str) or not source.startswith("https://")):raise ValueError("来源链接须为HTTPS")
    routes=value.get("routes",[])
    if not isinstance(routes,list) or len(routes)>1000:raise ValueError("路线无效")
    for route in routes:
        if route.get("region") not in ("trosky","kuttenberg") or not isinstance(route.get("points"),list) or len(route["points"])>3000:raise ValueError("路线无效")
        for point in route["points"]:
            if not isinstance(point,list) or len(point)!=2 or not all(isinstance(n,(int,float)) and not isinstance(n,bool) and 0<=n<=1 for n in point):raise ValueError("路线坐标无效")
    positions=value.get("positions",{})
    if not isinstance(positions,dict):raise ValueError("位置记录无效")
    atlas_positions=value.get("atlasPositions",{})
    if not isinstance(atlas_positions,dict):raise ValueError("中文地图位置无效")
    for region,point in {**positions,**atlas_positions}.items():
        if region not in ("trosky","kuttenberg") or not isinstance(point,dict) or not all(isinstance(point.get(k),(int,float)) and not isinstance(point[k],bool) and 0<=point[k]<=1 for k in ("x","y")):raise ValueError("手动位置坐标无效")
    for region in ("trosky","kuttenberg"):
        m=value.get("maps",{}).get(region,{})
        url=m.get("url","")
        if not isinstance(url,str) or not (url in ("/assets/"+region+".jpg","/assets/atlas-"+region+".jpg") or url.startswith("/uploads/")) or ".." in url:raise ValueError("底图路径无效")
    anchors=value.get("anchors",[])
    if not isinstance(anchors,list) or len(anchors)>1000:raise ValueError("地标数据无效")
    for a in anchors:
        if not isinstance(a,dict) or a.get("region") not in ("trosky","kuttenberg") or not isinstance(a.get("name"),str):raise ValueError("地标数据无效")
        if not all(isinstance(a.get(k),(int,float)) and not isinstance(a[k],bool) and 0<=a[k]<=1 for k in ("x","y")):raise ValueError("地标坐标无效")
    value.setdefault("anchors",[]);value.setdefault("routes",[]);value.setdefault("positions",{})
    celestial=value.get("celestial",{"observations":[]})
    if not isinstance(celestial,dict) or not isinstance(celestial.get("observations"),list) or len(celestial["observations"])>3000:raise ValueError("观测日志无效")
    for o in celestial["observations"]:
        if not isinstance(o,dict) or o.get("body") not in ("sun","moon") or o.get("region") not in ("trosky","kuttenberg"):raise ValueError("观测内容无效")
        if not isinstance(o.get("bearing"),(int,float)) or isinstance(o["bearing"],bool) or not 0<=o["bearing"]<360:raise ValueError("方位无效")
        import re
        if not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d",str(o.get("time",""))):raise ValueError("观测时间无效")
        for k in ("day","note"):
            if not isinstance(o.get(k),str) or len(o[k])>300:raise ValueError("观测文本无效")
    if "atlasMaps" in value:
        for region in ("trosky","kuttenberg"):
            if value["atlasMaps"].get(region,{}).get("url")!="/assets/atlas-"+region+".jpg":raise ValueError("中文底图路径无效")
    return value
def load_state():
    path=STORE/"state.json"
    if path.exists():return validate(json.loads(path.read_text(encoding="utf-8")))
    return json.loads((DIST/"seed.json").read_text(encoding="utf-8"))
def write_state(state):
    path=STORE/"state.json"
    if path.exists():
        previous=STORE/"state.previous.json"
        previous.write_bytes(path.read_bytes())
    temp=STORE/"state.tmp"
    with temp.open("w",encoding="utf-8") as stream:
        json.dump(state,stream,ensure_ascii=False,indent=2);stream.flush();os.fsync(stream.fileno())
    temp.replace(path)
def image_bytes(data):
    if not isinstance(data,str):raise ValueError("底图无效")
    head,sep,body=data.partition(",")
    ext={"data:image/png;base64":"png","data:image/jpeg;base64":"jpg","data:image/webp;base64":"webp"}.get(head)
    if not sep or not ext:raise ValueError("只支持PNG、JPEG、WebP图片")
    try:raw=base64.b64decode(body,validate=True)
    except Exception:raise ValueError("底图编码无效")
    if not raw or len(raw)>20*1024*1024:raise ValueError("底图须小于20MB")
    if ext=="png" and not raw.startswith(b"\x89PNG\r\n\x1a\n"):raise ValueError("PNG内容无效")
    if ext=="jpg" and not raw.startswith(b"\xff\xd8\xff"):raise ValueError("JPEG内容无效")
    if ext=="webp" and not (raw[:4]==b"RIFF" and raw[8:12]==b"WEBP"):raise ValueError("WebP内容无效")
    return raw,ext
def save_image(data):
    raw,ext=image_bytes(data)
    name=hashlib.sha256(raw).hexdigest()+"."+ext
    folder=STORE/"uploads";folder.mkdir(exist_ok=True)
    (folder/name).write_bytes(raw)
    return "/uploads/"+name
class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(DIST),**kwargs)
    def log_message(self,*args):pass
    def permitted(self):
        host=self.headers.get("Host","").split(":")[0]
        return host in ("127.0.0.1","localhost")
    def send_json(self,value,status=200):
        raw=json.dumps(value,ensure_ascii=False).encode("utf-8")
        self.send_response(status);self.send_header("Content-Type","application/json; charset=utf-8");self.send_header("Content-Length",str(len(raw)));self.send_header("Cache-Control","no-store");self.end_headers();self.wfile.write(raw)
    def end_headers(self):
        self.send_header("Cache-Control","no-cache")
        self.send_header("X-Content-Type-Options","nosniff")
        self.send_header("Content-Security-Policy","default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; object-src 'none'; frame-ancestors 'none'")
        super().end_headers()
    def do_GET(self):
        if not self.permitted():return self.send_json({"error":"只允许本机访问"},403)
        if self.path in ("/api/state","/api/export"):
            with LOCK:
                state=load_state()
                if self.path=="/api/export":
                    package={"app":"kcd2-map-assistant","schema":1,"state":state,"mapImages":{}}
                    for region,m in state["maps"].items():
                        if m["url"].startswith("/uploads/"):
                            path=STORE/"uploads"/Path(m["url"]).name
                            mime={".png":"png",".jpg":"jpeg",".webp":"webp"}[path.suffix]
                            package["mapImages"][region]="data:image/"+mime+";base64,"+base64.b64encode(path.read_bytes()).decode()
                    return self.send_json(package)
                return self.send_json(state)
        if self.path.startswith("/uploads/"):
            name=self.path[len("/uploads/"):]
            if "/" in name or "\\" in name or not name or ".." in name:return self.send_json({"error":"无效底图"},404)
            path=STORE/"uploads"/name
            if not path.is_file():return self.send_json({"error":"底图不存在"},404)
            raw=path.read_bytes()
            self.send_response(200);self.send_header("Content-Type",{".png":"image/png",".jpg":"image/jpeg",".webp":"image/webp"}.get(path.suffix,"application/octet-stream"));self.send_header("Content-Length",str(len(raw)));self.end_headers();self.wfile.write(raw);return
        return super().do_GET()
    def do_POST(self):
        if not self.permitted():return self.send_json({"error":"只允许本机访问"},403)
        origin=self.headers.get("Origin")
        if origin and origin not in ("http://127.0.0.1:"+str(self.server.server_port),"http://localhost:"+str(self.server.server_port)):return self.send_json({"error":"来源不匹配"},403)
        try:
            length=int(self.headers.get("Content-Length","0"))
            if not 0<length<=MAX:raise ValueError("数据过大或为空")
            body=json.loads(self.rfile.read(length))
            with LOCK:
                current=load_state()
                if body.get("revision")!=current.get("revision",0):return self.send_json({"error":"另一个窗口已更新记录。请先导出当前修改，再重新打开页面。"},409)
                if self.path=="/api/stop":
                    self.send_json({"stopped":True});threading.Thread(target=self.server.shutdown,daemon=True).start();return
                if self.path=="/api/save":state=validate(body["state"])
                elif self.path=="/api/import":
                    package=body["package"]
                    if package.get("app")!="kcd2-map-assistant":raise ValueError("请选择本软件导出的JSON备份")
                    state=validate(package["state"])
                    images=package.get("mapImages",{})
                    if not isinstance(images,dict) or not set(images)<= {"trosky","kuttenberg"}:raise ValueError("备份底图数据无效")
                    for value in images.values():image_bytes(value)
                    for region,m in state["maps"].items():
                        if m["url"].startswith("/uploads/") and region not in images:raise ValueError("备份缺少自定义底图")
                    for region,data in images.items():state["maps"][region]["url"]=save_image(data)
                    backup_folder=STORE/"backups";backup_folder.mkdir(exist_ok=True)
                    backup=backup_folder/("before-import-"+datetime.datetime.now().strftime("%Y%m%d-%H%M%S")+"-"+uuid.uuid4().hex[:6]+".json")
                    backup.write_text(json.dumps(current,ensure_ascii=False,indent=2),encoding="utf-8")
                elif self.path=="/api/map":
                    region=body["region"]
                    if region not in ("trosky","kuttenberg"):raise ValueError("区域无效")
                    state=current
                    if body.get("reset"):state["maps"][region]={"url":"/assets/"+region+".jpg","northUp":True}
                    else:state["maps"][region]={"url":save_image(body["data"]),"northUp":bool(body.get("northUp",False))}
                else:return self.send_json({"error":"不存在的操作"},404)
                state["revision"]=current.get("revision",0)+1
                write_state(state)
                return self.send_json({"revision":state["revision"],"state":state} if self.path!="/api/save" else {"revision":state["revision"]})
        except (ValueError,KeyError,TypeError) as error:return self.send_json({"error":str(error)},400)
        except Exception:return self.send_json({"error":"写入失败，请检查数据文件夹权限和可用磁盘空间。"},500)
def main():
    global STORE
    parser=argparse.ArgumentParser()
    parser.add_argument("--port",type=int,default=8872)
    parser.add_argument("--data-dir",type=Path,default=ROOT/"data")
    parser.add_argument("--no-browser",action="store_true")
    args=parser.parse_args();STORE=args.data_dir.resolve();STORE.mkdir(parents=True,exist_ok=True)
    try:load_state()
    except Exception as error:raise SystemExit("记录文件无法读取；已保留原文件，请恢复备份。"+str(error))
    try:server=ThreadingHTTPServer(("127.0.0.1",args.port),Handler)
    except OSError:
        raise SystemExit("端口已被占用。若已有地图窗口请使用原窗口；否则加 --port 8873。")
    url="http://127.0.0.1:"+str(server.server_port)
    print("Local map: "+url,flush=True);print("Data: "+str(STORE),flush=True)
    if not args.no_browser:threading.Timer(.5,lambda:webbrowser.open(url)).start()
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()
if __name__=="__main__":main()
