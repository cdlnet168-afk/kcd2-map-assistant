import json,subprocess,sys,urllib.request,webbrowser,socket
from pathlib import Path
root=Path(__file__).resolve().parent
port=8872
for candidate in range(8872,8882):
    url="http://127.0.0.1:"+str(candidate)
    try:
        with urllib.request.urlopen(url+"/api/state",timeout=.5) as response:state=json.load(response)
        if state.get("schema")==1 and "anchors" in state and "records" in state:
            webbrowser.open(url);sys.exit(0)
    except Exception:pass
    test=socket.socket()
    try:test.bind(("127.0.0.1",candidate));port=candidate;break
    except OSError:continue
    finally:test.close()
subprocess.Popen([sys.executable,"-X","utf8",str(root/"server.py"),"--port",str(port)],
                 cwd=root,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
